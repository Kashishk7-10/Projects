package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UnBlockAccount extends JFrame  implements ActionListener{
    JButton Login,singn,home;
     JPasswordField passwordf;
     JTextField cnicf;
     
    UnBlockAccount()
    {
       setTitle("UnBlock Account");
        
         setLayout(null);
         
         ImageIcon logo1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
         Image logo2=logo1.getImage().getScaledInstance(170,170,Image.SCALE_DEFAULT);
         ImageIcon logo3=new ImageIcon(logo2);
         JLabel logo4=new JLabel(logo3);
         logo4.setBounds(300,40,250,250);
         add(logo4);
         
        JLabel text=new JLabel("Master Bank");
        text.setFont(new Font("Osward",Font.BOLD,60));
        text.setBounds(510,100,1000,100);
        add (text);
        
        JLabel slogan =new JLabel("Master your finances with Bank Master");
        slogan.setFont(new Font("Osward",Font.ITALIC,15));
        slogan.setBounds(550,165,800,45);
        add (slogan);
         
        /*
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
        Image i2=i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel label=new JLabel(i3);
        label.setBounds(600,210,100,100);
        add(label);
         */
         JLabel logintext=new JLabel("UnBlock Account Portal");
        logintext.setFont(new Font("Osward",Font.BOLD,20));
        logintext.setBounds(600,250,1000,100);
        add (logintext);
        
        
        JLabel cnic=new JLabel("ID:");
        cnic.setFont(new Font("Osward",Font.BOLD,20));
        cnic.setBounds(500,325,1000,100);
        add (cnic);
        
         cnicf=new JTextField();
       cnicf.setBounds(620,360,200,30);
       cnicf.setFont(new Font("Osward",Font.BOLD,18));
       add(cnicf);
        
       /*
        JLabel password=new JLabel("Pin:");
        password.setFont(new Font("Osward",Font.BOLD,20));
        password.setBounds(500,350,1000,100);
        add (password);
        
         passwordf=new JPasswordField();
       passwordf.setBounds(620,390,200,20);
       passwordf.setFont(new Font("Osward",Font.BOLD,18));
       add(passwordf);
       */
       
        Login=new JButton("UnBlock");
        Login.setBounds(550,445,200,30);
         Login.setFocusable(false);
        Login.addActionListener(this);
        add(Login);
        /*
        singn=new JButton("SINGN UP");
        singn.setBounds(550,480,200,30);
        singn.setFocusable(false);
        singn.addActionListener(this);
        add(singn);
        */
        home=new JButton("Back");
        home.setBounds(550,500,200,30);
         home.setFocusable(false);
        home.addActionListener(this);
        add(home);
        
         JLabel rights=new JLabel("Copyright © 2023 All Rights Reserved");
         rights.setFont(new Font("Osward",Font.ITALIC,10));
        rights.setBounds(400,550,800,45);
        add (rights);

        
        
         getContentPane().setBackground(Color.WHITE);
        
        setSize(1375,750);
        setVisible(true);
        setLocation(0,0);
    }
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()== Login)
        {
       Conn conn = new Conn();
String cardnumber = cnicf.getText();

String query = "SELECT * FROM blockaccount WHERE card_number = '" + cardnumber + "'";
try {
    ResultSet rs = conn.s.executeQuery(query);
    if (rs.next()) {
        String query2 = "DELETE FROM blockaccount WHERE card_number = '" + cardnumber + "'";
        try {
            int rowsDeleted = conn.s.executeUpdate(query2);
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Account UnBlocked  successfully");
                setVisible(false);
                new BlockPortal().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Account was not found");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Card number not found in block list");
    }
} catch (Exception e) {
    System.out.println(e);
}
        }
       
        if(ae.getSource()== home)
        {
        setVisible(false);
        new BlockPortal();
         
        }
    }
    public static void main(String args[])
    {
       new UnBlockAccount(); 
    }
    
}
