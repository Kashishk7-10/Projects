package bank.management.system;

import java.sql.*;


public class Conn {
    
    Connection c;
    public Statement s;
    
    public Conn()
    {
        try{
            
            c=DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem","root","MySQL@#2003");
            s=c.createStatement();
            
        }catch(Exception e)
        {
            System.out.println(e);
            
        }
    }
    
}
