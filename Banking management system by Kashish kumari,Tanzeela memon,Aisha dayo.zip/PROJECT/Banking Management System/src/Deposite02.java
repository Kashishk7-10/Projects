package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.toedter.calendar.JDateChooser;
import java.util.*;

public class Deposite02 extends JFrame implements ActionListener{
    
     JTextField amountf;
       JButton previous,next;
       String pinnumber;
       int amount;
       
    Deposite02(String pinnumber)
    {
        this.pinnumber=pinnumber;
        
        setTitle("Deposit");
        
         setLayout(null);
         
         ImageIcon logo1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
         Image logo2=logo1.getImage().getScaledInstance(70,70,Image.SCALE_DEFAULT);
         ImageIcon logo3=new ImageIcon(logo2);
         JLabel logo4=new JLabel(logo3);
         logo4.setBounds(140,10,250,250);
         add(logo4);
         
        JLabel text=new JLabel("Master Bank");
        text.setFont(new Font("Osward",Font.BOLD,30));
        text.setBounds(310,80,1000,100);
        add (text);
        
        JLabel slogan =new JLabel("Master your finances with Bank Master");
        slogan.setFont(new Font("Osward",Font.ITALIC,7));
        slogan.setBounds(330,130,800,45);
        add (slogan);
        
        JLabel transection = new JLabel("Deposte Poatal");
        transection.setFont(new Font("Osward",Font.BOLD,20));
        transection.setBounds(500,200,300,50);
        add(transection);
        
        
        JLabel amount=new JLabel("Deposite Amount:");
        amount.setFont(new Font("Osward",Font.BOLD,20));
        amount.setBounds(350,310,300,50);
        add (amount);
        
        amountf=new JTextField();
        amountf.setBounds(550,320,250,25);
        add(amountf);
        
        
         previous=new JButton("Back");
        previous.setBounds(480,475,150,30);
        previous.addActionListener(this);
        add(previous);
        
        next=new JButton("Deposite");
        next.setBounds(650,475,150,30);
        next.addActionListener(this);
        add(next);

        
         JLabel rights=new JLabel("Copyright © 2023 All Rights Reserved");
         rights.setFont(new Font("Osward",Font.ITALIC,10));
        rights.setBounds(400,550,800,45);
        add (rights);

        
        getContentPane().setBackground(Color.WHITE);
         
         
        setSize(1375,750);
        setVisible(true);
        setLocation(0,0); 
        
    }
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()== next)
        {
            String number=amountf.getText();
            
            //amount=Integer.valueOf(number);
            //amount=Integer.parseInt(number);
            
            Date date=new Date();
            if(number.equals(""))
            {
                JOptionPane.showMessageDialog(null,"Enter Deposite Amount");
                
            }
            else
            {
                amount=Integer.parseInt(number);
                if(amount<0)
                {
                    JOptionPane.showMessageDialog(null,"Invalid Amount!!");
                
                }
                else
                {
                try{
              Conn c=new Conn();
                
               String query="insert into bank values ('"+pinnumber+"','"+date+"','Deposit', '"+number+"')";
                
                c.s.executeUpdate(query);  
                 JOptionPane.showMessageDialog(null,"Rs:"+number+" Amount Deposite Succecfully!!");
                 
                setVisible(false);
                new Transections(pinnumber).setVisible(true);
               // new Transections(pinnumber).setVisible(true);
            }
                catch(Exception a)
                {
                    System.out.println(a);
                }
            }
            
        }
        }
        if(ae.getSource()== previous)
        {
            setVisible(false);
            new Transections(pinnumber).setVisible(true);
        }
        
        /*
        
         JTextField emailf,phonef,adressf;
     JComboBox education;
     JRadioButton married,unmarried,other;
        
         if(ae.getSource()== next)
        {
        
        String formno=""+ formn;
        
        String email=emailf.getText();
        String phone=phonef.getText();
        String adress=adressf.getText();
        String seducation=(String)educationf.getSelectedItem();
        
        String status=null;
        
        if(married.isSelected())
        {
            status="Married";
        }
        else if(unmarried.isSelected())
        {
            status="Unmarried";
        }
        else if(other.isSelected())
        {
            status="Other";
        }
       
        
        try{
            if(email.equals("") ){
                JOptionPane.showMessageDialog(null, "Email is required ");
                
            }
            else  if(phone.equals("") ){
                JOptionPane.showMessageDialog(null, "Phone No: is required ");
                
            }
             else  if(adress.equals("") ){
                JOptionPane.showMessageDialog(null, "Adress is required ");
                
            }
              else  if(seducation.equals("") ){
                JOptionPane.showMessageDialog(null, "Select Your Degree ");
                
            }
               else  if(status.equals("") ){
                JOptionPane.showMessageDialog(null, "Select Your Status");
                
            }
              
            else
            {
                Conn c=new Conn();
                
               String query="insert into AdditionalInfo values ('"+formno+"','"+email+"', '"+phone+"', '"+adress+"', '"+seducation+"')";
                
                c.s.executeUpdate(query);
                
                setVisible(false);
                
                new AccountDetails(formn).setVisible(true);
                
                        
            }
        }catch(Exception e)
        {
            System.out.println(e);
        }
        
        if(ae.getSource()== previous)
        {
            setVisible(false);
         new SingnUp(); 
         
        }
        else if(ae.getSource()== next)
        {
            setVisible(false);
         new AccountDetails(); 
            
        }

        }
          else if(ae.getSource()== previous)
        {
            setVisible(false);
         new SingnUp().setVisible(true); 
            
        } */
    }
   public static void main(String args[])
   {
       new Deposite02("");
   }
    
}

