
package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Home extends JFrame implements ActionListener {
    
    JButton Customer,Bank,Exit;
    
    Home()
    {
        setTitle("Home");
        
        
         setLayout(null);
         
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
         Image i2=i1.getImage().getScaledInstance(170,170,Image.SCALE_DEFAULT);
         ImageIcon i3=new ImageIcon(i2);
         JLabel label=new JLabel(i3);
         label.setBounds(300,40,250,250);
         add(label);
         
        
        JLabel text=new JLabel("Master Bank");
        text.setFont(new Font("Osward",Font.BOLD,60));
        text.setBounds(510,100,1000,100);
        add (text);
        
        JLabel slogan =new JLabel("Master your finances with Bank Master");
        slogan.setFont(new Font("Osward",Font.ITALIC,15));
        slogan.setBounds(550,165,800,45);
        add (slogan);
        
         JLabel rights=new JLabel("Copyright © 2023 All Rights Reserved");
         rights.setFont(new Font("Osward",Font.ITALIC,10));
        rights.setBounds(400,550,800,45);
        add (rights);
        
        Customer=new JButton("Custmor");
        Customer.setBounds(550,300,300,40);
         Customer.setFocusable(false);
        Customer.addActionListener(this);
        add(Customer);
        
        Bank=new JButton("Bank Authority");
        Bank.setBounds(550,350,300,40);
        Bank.setFocusable(false); // How do I get focus on button on App launch?
         Bank.addActionListener(this);
        add(Bank);
        
        Exit=new JButton("Exit");
        Exit.setBounds(550,400,300,40);
         Exit.setFocusable(false);
         Exit.addActionListener(this);
        add(Exit);
        
        
        getContentPane().setBackground(Color.WHITE);
        
        setSize(1375,750);
        setVisible(true);
        setLocation(0,0);
    }
    
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()== Customer)
        {
        setVisible(false);
        new Login();
         
        }
        else if(ae.getSource()== Bank)
        {
            setVisible(false);
            new BankLogin();
            
        }
        else if(ae.getSource()== Exit)
        {
            setVisible(false); 
        }
    }
    
    public static void main(String args[])
    {
        new Home();
    }
    
}