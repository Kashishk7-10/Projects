create database bankmanagementsystem;
show databases;
use bankmanagementsystem;
create table SingnUp(formno varchar(20) , namef varchar(20),fname varchar(20),cnic varchar(20),dob varchar(20),profation varchar(20),gender varchar(20));

show tables;
select * from SingnUp;
create table AdditionalInfo(formno varchar(20),email varchar(50),phone varchar(20),address varchar(70),eduaction varchar(20),state varchar(10));
select * from AdditionalInfo;
create table AccountDetails(formno varchar(20),Depositedate varchar(20),Deposite  varchar(70),AccountType varchar(20),cardNo varchar(25),pin varchar(20));
create table login(formno varchar(20),cardNo varchar(25),pin varchar(20));
create table banklogin(id varchar(25),pin varchar(20));
select * from banklogin;

select * from accountdetails;
select * from login;
create table bank(pin varchar(10),date varchar(50),status varchar(20),amount varchar(10));

select *from bank;
create table blockaccount(card_number varchar(30),Date varchar(45));

select *from blockaccount;